/**
 * Laborprüfung TI-Programmiertechnik.
 * Sommersemester 2015
 * Hochschule für Angewandte Wissenschaften, Hamburg
 */
package aufgabe1;

/**
 * Darth Vader ist eine spezielle SpielFigur.
 * 
 * @author Philipp Jenke
 *
 */
public class DarthVader {

}
